--copyright:Jan Joshua Laub 2022
--PROJECT:Razor-Linux
--Version: V1.4-Moonlight
--Beta


--code


--laden der images
logout = 0
function love.load()
	background = love.graphics.newImage("moon-15.jpg")
	love.window.setMode(1920,1080)
	logo = love.graphics.newImage("desktop/icon2.jpg")
	anzeige = love.graphics.newImage("desktop/anzeige.jpg")
	task = love.graphics.newImage("desktop/task.jpg")
	powerimg = love.graphics.newImage("desktop/power.jpg")
	powerpanelimg = love.graphics.newImage("desktop/powerpanel-2.jpg")
	--settingsimg = love graphics.newImage("desktop/settings.jp
	
end
function love.draw()
	if(logout == 0)
	then
		love.graphics.draw(background, 0, 0)
		love.graphics.draw(logo, 0, 0)
		love.graphics.draw(task, 178, 0)
		love.graphics.draw(powerimg,1820,0)
	else 
		love.graphics.draw(background,0,0)	
	end	
	x, y = love.mouse.getPosition( )
		
	if(task0 == 1)
	then
		--task0 wird weiter unten definiert
		love.graphics.draw(anzeige, 0, 100)
	end
	if(power == 1)
	then
		--power wird weiter unten definiert
		love.graphics.draw(powerpanelimg,1720,100)
	end
	if(settings == 1)
	then
		--hier kommt der code für den screen rechtsklick hin
	end
end
function love.mousepressed(y, x, button, istouch)
	--die events wereden hier gemanaged
	print("x:",x,"y:",y,"power",power,"button:",button)
	--das^ ist die zusammenfassung der events
	if(button == 1 and task0 == 1 and x > 156 and x < 200 and y < 178)
	then
		print("firefox")
		os.execute("firefox")
	end
	if(button == 1 and task0 == 1 and x > 100 and x < 156 and y < 178)
	then
		os.execute("minetest")
	end
	if(power == 1 and button == 1 and y > 1720 and x > 165 and x < 230)  
	then

		print("reboot")
	end
	if(power == 1 and button == 1 and y > 1720 and x > 230 and x < 400) 
	then
		print("of")
	end
	if(power == 1 and x > 100 and x < 200 and y > 1720 and button == 1)
	then
		--hier der logout
		logout = 1
	else
		logout = 0
	end 
	if(x < 100 and y < 178 and button == 1)
	then
		task0 = 1
	else
		task0 = 0
	end
	if(x < 100 and y > 1820 and button == 1)
	--das^ist das power statemant
	then
		power = 1
	else 
		power = 0
	end
	if(button == 2 and x > 100 and power == 0 and logout == 0 and task0 == 0)
	then
		settings = 1
		xf = x
		yf = y
	else 
		settings = 0
	end
end
