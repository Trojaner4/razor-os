#!/usr/bin/python3
import keyboard
import os
while True:
	if keyboard.read_key() == "alt":
		if keyboard.read_key() == "q":
			os.system("pkill -f terminal")
			break
