#!/usr/bin/python3
import pygame
from pygame.locals import *
import os
spielaktiv = True
drei = 300,300
pygame.init()
W, H = 1920, 1080
SCHWARZ = ( 0, 0, 0)
WEISS   = ( 255, 255, 255)
FPS = 60
pos_iconx = 190
pos_icony = 110
drauf = "nein"
powerpanel = pygame.image.load("desktop/power-panel.jpg")
fenster = pygame.display.set_mode((W, H))
power = pygame.image.load("desktop/power.jpg")
terminal = pygame.image.load("desktop/terminal.jpg")
#gameDisplay = pygame.display.set_mode((1920,1080))
pygame.display.set_caption("""Razor Linux 'Aurora'""")
clock = pygame.time.Clock()
anzeige = pygame.image.load("desktop/anzeige.jpg")
spielerfigur = pygame.image.load("desktop/Razor-Linux.png")
bildgroessen = 0,0
icon = pygame.image.load("desktop/icon2.jpg")
rechtsklickdesktopbackground = pygame.image.load("desktop/klick-desk.jpg")
#cursor = pygame.image.load("cursor.png")
#task = cursor
dp = "nein"
g = 0,0
pp = 1720,100
powerpos =1820,0
terminalpos = 178,0
anzeigepos = 0,100
while True:
 while spielaktiv:
    fenster.blit(rechtsklickdesktopbackground,drei)
    fenster.blit(power,powerpos)
    fenster.blit(icon, g)
    pygame.mouse.set_cursor(*pygame.cursors.arrow)
    fenster.blit(rechtsklickdesktopbackground,drei)
    #pos = pygame.mouse.get_pos()
    #posx,posy = pygame.mouse.get_pos()
    #fenster.blit(cursor, pos)
                           # Überprüfen, ob Nutzer eine Aktion durchgeführt hat
    for event in pygame.event.get():
        # Beenden bei [ESC] oder [X]
        #if event.type==QUIT or (event.type==KEYDOWN and event.key==K_ESCAPE):
         #   spielaktiv = False
    #fenster.blit(spielerfigur, bildgroessen)
    # Spiellogik
       # pos = pygame.mouse.get_pos()
        fenster.blit(terminal,terminalpos)
        posx,posy = pygame.mouse.get_pos()
        #fenster.blit(cursor, pos)
        if posx >= pos_iconx:
            if event.type == pygame.MOUSEBUTTONUP:
                 drauf = "nein"
        pygame.mouse.set_cursor(*pygame.cursors.arrow)
        if posy >= pos_icony:
            if event.type == pygame.MOUSEBUTTONUP:
                 drauf = "nein"
                 
        if posx <= pos_iconx:
            if posy <= pos_icony:
                 if event.type == pygame.MOUSEBUTTONUP:
                     #fenster.blit(icon, bildgroessen)
                     drauf = "ja"
        #fenster.blit(icon,bildgroessen)
        if posx >= 178:
                 if posy <= 100:
                       if posx <= 278:
                              if event.type == pygame.MOUSEBUTTONUP:
                                    os.system("./kill-terminal.py & ./usr/bin/xfce4-terminal")
        if posx >= 1820:
                 if posy <= 100:
                        if event.type == pygame.MOUSEBUTTONUP:
                                dp = "ja"
        if dp == "ja":
                  fenster.blit(powerpanel,pp)
                  while True:
                       if dp == "nein":
                            break
                       for event in pygame.event.get():
                             if event.type == pygame.MOUSEBUTTONUP:
                                   print("posx",posx,"posy",posy)
                             pygame.display.flip()
                             clock.tick(FPS)
                             posx,posy = pygame.mouse.get_pos()
                             print(posx,posy)
                             fenster.blit(powerpanel,pp)
                             if posx >= 1720:
                                    if posy >= 100:
                                        if posy <= 170:
                                            if event.type == pygame.MOUSEBUTTONUP:
                                                os.system("startx ./bootloader.py")
                                    if posy >= 170:
                                         if posy <= 230:
                                                if event.type == pygame.MOUSEBUTTONUP:
                                                     os.system("reboot")
                                    if posy >= 230:
                                         if posy <= 400:
                                                if event.type == pygame.MOUSEBUTTONUP:
                                                     os.system("shutdown -h")
                             else:
                                 if event.type == pygame.MOUSEBUTTONUP:
                                       dp = "nein"
                                       break


        if drauf == "ja":
                 print("ja")
                 fenster.blit(anzeige,anzeigepos)
                 while True:
                  if drauf == "nein":
                   break
                  for event in pygame.event.get():
                     pos = pygame.mouse.get_pos()
                     posx,posy = pygame.mouse.get_pos()
                     fen
                     if posx <= 200:
                          if posy >= 175:
                                if posy <= 280:
                                      if event.type == pygame.MOUSEBUTTONUP:
                                           os.system("./kill-firefox.py & ./usr/bin/firefox")
                          posx,posy = pygame.mouse.get_pos()
                          if posy >= 100:
                              print("ja1")
                              if posy <= 170:
                                 print("ja2")
                                 if event.type == pygame.MOUSEBUTTONUP:
                                    print("ja3")
                                    os.system("./kill-minetest.py & ./root/minetest/bin/minetest")
                                    print("minetest")
                     if posx >= 200:
                               if event.type == pygame.MOUSEBUTTONUP:
                                      print("-------------------EXIT------------------")
                                      drauf = "nein"
                                      break
        else:
                 if event.type == pygame.MOUSEBUTTONDOWN:
                            while True:
                                   for event in pygame.event.get():
                                          posx,posy = pygame.mouse.get_pos()
                                          #desktop = pygame.image.load("desktop/edit.jpg")
                                          #fenster.blit(desktop,pos)
                                          print("--------------JAAAAAAAAAAAA!!!!_______")
                                          break

        pygame.display.flip()
        clock.tick(FPS)
        print(posx,posy)
        fenster.blit(spielerfigur, bildgroessen)
        fenster.blit(icon,g)
        fenster.blit(power,powerpos)
        fenster.blit(terminal,terminalpos)

        #pos = pygame.mouse.get_pos()
        #print(pos) 
    # Spielfeld löschen
    #fenster.fill(WEISS)

    # Spielfeld/figuren zeichnen

    # Fenster aktualisieren
    pygame.display.flip()
    clock.tick(FPS)
    
