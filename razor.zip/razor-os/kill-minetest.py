#!/usr/bin/python3
import os
import keyboard
while True:
	if keyboard.read_key() == "alt":
		if keyboard.read_key() == "q":
			os.system("pkill -f minetest")
			break
