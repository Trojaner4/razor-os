--copyright:Jan Joshua Laub 2022
--PROJECT:Razor-Linux
--Version: V1.4-Moonlight
--Beta


--code


--laden der images
function love.load()
	background = love.graphics.newImage("moon-15.jpg")
	love.window.setMode( 1920,1080)
	logo = love.graphics.newImage("desktop/icon2.jpg")
	anzeige = love.graphics.newImage("desktop/anzeige.jpg")
	task = love.graphics.newImage("desktop/task.jpg")
	powerimg = love.graphics.newImage("desktop/power.jpg")
	powerpanelimg = love.graphics.newImage("desktop/powerpanel-2.jpg")
end
function love.draw()
	--zeigen der bilder
	love.graphics.draw(background, 0, 0)
	love.graphics.draw(logo, 0, 0)
	love.graphics.draw(task, 178, 0)
	love.graphics.draw(powerimg,1820,0)
	x, y = love.mouse.getPosition( )	
	if(task0 == 1)
	then
		--task0 wird weiter unten definiert
		love.graphics.draw(anzeige, 0, 100)
	end
	if(power == 1)
	then 
		--power wird weiter unten definiert
		love.graphics.draw(powerpanelimg,1720,100)
	end
end
function love.mousepressed(y, x, button, istouch)
	--die events wereden hier gemanaged
	print("x:",x,"y:",y,"power",power,"button:",button)
	--das^ ist die zusammenfassung der events
	if(power == 1 and x > 100 and x < 200 and y > 1720 and button == 1)
	then
		--hier der logout
	end 
	if(x < 100 and y < 178 and button == 1)
	then
		task0 = 1
	else
		task0 = 0
	end
	if(x < 100 and y > 1820 and button == 1)
	--das^ist das power statemant
	then
		power = 1
	else 
		power = 0
	end
end
