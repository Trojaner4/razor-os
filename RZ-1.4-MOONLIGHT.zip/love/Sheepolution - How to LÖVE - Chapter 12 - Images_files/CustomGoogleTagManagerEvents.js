function guid(){function s4(){return Math.floor((1+Math.random())*0x10000).toString(16).substring(1);}
return s4()+s4()+'-'+s4()+'-'+s4()+'-'+s4()+'-'+s4()+s4()+s4();}
function trackSignup(){try{dataLayer.push({'event':'GTMSignUp','method':'onsite'});}
catch(err){}}
function trackEvent(name){try{dataLayer.push({'event':name,'method':'onsite'});}
catch(err){console.log(err);}}
function trackCustomEvent(name,extraInfo){try{dataLayer.push({'event':'custom_'+name,'method':'onsite','extraInfo':extraInfo});}
catch(err){console.log(err);}}
function trackTransaction(){dataLayer.push({'event':'GTMTransaction','method':'onsite'});}
function enableOptimize(experimentName){try{if(typeof dataLayer!=="undefined"){if(experimentName&&experimentName!=''){dataLayer.push({'event':'optimize.activate_'+experimentName});}
else{dataLayer.push({'event':'optimize.activate'});}}
else{setTimeout(enableOptimize,250);}}
catch(err){console.log(err);}}
function trackExperiment(experimentId,variationId){try{var trackExp=function(){try{ga('gtm2.set','exp',experimentId.toString()+'.'+variationId.toString());ga('gtm2.send','event','Experiment','Trigger',experimentId.toString()+'.'+variationId.toString());console.log('expe:'+experimentId.toString()+" v"+variationId);}
catch(err){}}
setTimeout(trackExp,500);}
catch(err){console.log('ga undefined *');}}
function trackGoldPurchase(){dataLayer.push({"event":"GTMGoldPurchase","ecommerce":{"purchase":{"actionField":{"id":"gold"+guid(),"affiliation":"none","revenue":"6.00","tax":"0.00","shipping":"0.00","coupon":"none"},"products":[{"id":"gold"+guid(),"name":"Gold","price":"6.00","brand":"Ko-fi","category":"Gold","variant":"monthly","quantity":1}]}}});console.log('gtm gold');}