$('div.modal').on('show.bs.modal',function(){try{var modal=this;if(modal.id==undefined||modal.id==='addContentMenuModal'||modal.id==='uploadModal')
{console.log('returned');return;}
var hash=modal.id;window.location.hash=hash;window.onhashchange=function(event){if((!location.hash&&(!location.href.endsWith('#'))||location.href.endsWith('#gallerytab')||location.href.endsWith('#poststab')))
{if(event.oldURL==undefined||event.oldURL.includes('#'))
{$(modal).modal('hide');}}}}catch(err){}});$('div.modal').on('hidden.bs.modal',function(){try{var hash=this.id;if(modal.id==undefined||modal.id==='addContentMenuModal'||modal.id==='uploadModal')
{return;}
console.log('close');history.replaceState('',document.title,window.location.pathname);}catch(err){}});window.onhashchange=function(event){this.console.log('hash change')
if(!location.hash&&!location.href.endsWith('#'))
{if(event.oldURL==undefined||(event.oldURL.includes('#gallerytab')||(event.oldURL.includes('#poststab'))))
{goToPageTab();}}}