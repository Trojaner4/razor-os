$(document).ready(function(){configureToastr(0);var inputs=$('.returnblursinput').keypress(function(e){if(e.which==13){e.preventDefault();var nextInput=inputs.get(inputs.index(this)+1);if(nextInput){nextInput.focus();}}});try{if(_triggerShareNewPostModal)
$("#shareNewPostModal").modal();}catch{}});function doToolTips(){$("[rel=tooltip]").tooltip({placement:'auto'});}
function validateEmail(email){var value=email.trim();var re=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;return re.test(String(value).toLowerCase());}
function getCookie(cname){var name=cname+"=";var decodedCookie=decodeURIComponent(document.cookie);var ca=decodedCookie.split(';');for(var i=0;i<ca.length;i++){var c=ca[i];while(c.charAt(0)==' '){c=c.substring(1);}
if(c.indexOf(name)==0){return c.substring(name.length,c.length);}}
return "";}
function inputEnforceOnlyWholePositiveNumbers(event){if(event.charCode==8||event.charCode==0||event.charCode==13)
return null;var isValid=event.charCode>=48&&event.charCode<=57;if(!isValid)
event.preventDefault();return isValid;}
function createMembershipOrder(tierId){showSpinner();fetch('/api/subscriptions/membership/create',{method:'POST',body:JSON.stringify({tierId:tierId}),headers:{'Content-Type':'application/json'},credentials:'same-origin'}).then(function(res){if(!res.ok&&res.success==null)
return{success:false};return res.json();}).then(function(data){if(data.success==false){ShowGenericError(data.friendly_error_message);hideSpinner();return;}
window.location='/summary/'+data.transactionId;});}
function StartConversation(pageOrTransactionId){try{showSpinner();}catch(e){}
$.ajax({type:"POST",data:{},url:"/api/messages/start/"+pageOrTransactionId,success:function(data){if(data.ConversationId!=null){window.location.href="/messages/"+data.ConversationId;return;}else if(data.success==false){ShowGenericError(data.friendly_error_message);}},error:function(){ShowGenericError();},});}
function ShowGenericError(friendlyMessage){setTimeout(function(){hideSpinner();},200);var message=friendlyMessage;if(message==null)
message="This does not seem to work right now. Please try again later.";swal({title:'Oops, that didn\'t work',text:message,type:'warning',showCancelButton:false,confirmButtonColor:'#ff5f5f',cancelButtonColor:'#aaa',confirmButtonText:'Ok'})}
function getQueryStringByName(name,url=window.location.href){name=name.replace(/[\[\]]/g,'\\$&');var regex=new RegExp('[?&]'+name+'(=([^&#]*)|&|#|$)'),results=regex.exec(url);if(!results)return null;if(!results[2])return '';return decodeURIComponent(results[2].replace(/\+/g,' '));}
function isNumeric(str){if(typeof str=="number")return true;if(typeof str!="string")return false;return!isNaN(str)&&!isNaN(parseFloat(str));}
var toastrSetupComplete=false;function configureToastr(retryCount){var deferred=$.Deferred();if(retryCount>5){deferred.resolve();return deferred.promise();}
try{toastr.options.timeOut=1000;toastr.options.positionClass="toast-top-center";toastrSetupComplete=true;deferred.resolve();}catch{setTimeout(function(){configureToastr(retryCount+1).done(function(){deferred.resolve();});},500);}
return deferred.promise();}
function sendToastrSuccess(message){sendToastrMessage("success",message,0);}
function sendToastrWarning(message,retryCount){sendToastrMessage("warning",message,0);}
function sendToastrError(message,retryCount){sendToastrMessage("error",message,0);}
function sendToastrMessage(type,message,retryCount){if(retryCount>5)
return;try{if(!toastrSetupComplete){configureToastr(0).done(function(){toastrMessage(type,message);});}else{toastrMessage(type,message);}}catch{setTimeout(function(){sendToastrMessage(type,message,retryCount+1);},500);}}
function toastrMessage(type,message){try{if(type==="success")
toastr.success(message,'');if(type==="warning")
toastr.warning(message,'');if(type==="error")
toastr.error(message,'');}catch{}}
window.refundFunctions={refundReason:'',cancelSubDuringRefund:false,showRefundPopup:function(transactionId,amount,currency,isRecurring){refundReason='';cancelSubDuringRefund=false;var modalHtml='<br />You are about to refund <b>'+currency+''+amount+'</b>.<br /><br />If you wish, leave a reason for the refund'+
'<br /><br /><input class="form-control" placeholder="Enter a reason" onchange="window.refundFunctions.storeRefundReason(this.value);" onkeypress="this.onchange();" onpaste="this.onchange();" oninput="this.onchange();" />';if(isRecurring){modalHtml+=' <div class="checkbox checkbox-success kfds-btm-mrgn-24">'
+'<input id="cancelSub" name="cancelSub" type="checkbox" onchange="window.refundFunctions.storeCancelSubDuringRefund($(\'#cancelSub\').prop(\'checked\'))" />'
+'<label for="cancelSub" tabindex="0">'
+'Also cancel the subscription'
+'</label>'
'</div>';}
swal({type:'warning',title:"Are you sure?",html:modalHtml,showCancelButton:true,closeOnConfirm:false,animation:"slide-from-top",confirmButtonText:'Refund'}).then((result)=>{if(result.value==true){showSpinner();$.ajax({type:"POST",ajaxasync:true,data:{transactionId:transactionId,reason:window.refundFunctions.refundReason,cancelSubscription:window.refundFunctions.cancelSubDuringRefund},dataType:'json',url:"/api/transaction/"+transactionId+"/refunds/submit",success:function(e){hideSpinner();try{$("#"+transactionId+"-refund-submitted").show();$("#"+transactionId+"-refund-cta").hide();}
catch(e){}
toastr.success("Your refund request has been submitted.");},error:function(e){hideSpinner();toastr.error("We could not refund this payment.");},});}})},storeRefundReason:function(value){window.refundFunctions.refundReason=value;},storeCancelSubDuringRefund:function(value){window.refundFunctions.cancelSubDuringRefund=value;console.log(value);}}
function getClientLocale(){if(typeof Intl!=='undefined'){try{return Intl.NumberFormat().resolvedOptions().locale;}catch(err){console.error("Cannot get locale from Intl");return 'en';}}}
function getDateStrToTheDay(dateObj){var locale=getClientLocale();let ye=new Intl.DateTimeFormat(locale,{year:'numeric'}).format(dateObj);let mo=new Intl.DateTimeFormat(locale,{month:'short'}).format(dateObj);let da=dateObj.getDate();var daStr=da+"";if(da<10)
daStr="0"+daStr;return daStr+" "+mo+", "+ye;}