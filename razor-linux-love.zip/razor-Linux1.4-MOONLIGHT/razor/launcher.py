import os
os.system("love.exe love")
